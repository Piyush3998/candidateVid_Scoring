// server.js (CommonJS) — workflow + soft-skill metrics + calendar slot invites + robust confirm
require("dotenv").config();

const express = require("express");
const path = require("path");
const fse = require("fs-extra");
const multer = require("multer");
const crypto = require("crypto");

// Calendar / Email
const nodemailer = require("nodemailer");
const { createEvent } = require("ics");
const { v4: uuidv4 } = require("uuid");

/* ---------- CONFIG ---------- */
const app = express();
const DEFAULT_PORT = Number(process.env.PORT) || 5050;
const ADMIN_KEY = process.env.ADMIN_KEY || "joblens123";

const ROOT = __dirname;
const PUBLIC_DIR = path.join(ROOT, "public");
const DATA_DIR = path.join(ROOT, "data");
const UPLOAD_DIR = path.join(DATA_DIR, "uploads");
const DB_PATH = path.join(DATA_DIR, "data.json");
const QUESTIONS_PATH = path.join(DATA_DIR, "questions.json");
// Invites storage for slot booking
const INVITES_PATH = path.join(DATA_DIR, "invites.json");

const TZ = process.env.TZ || "Australia/Sydney";
const BASE_URL = process.env.BASE_URL || `http://127.0.0.1:${DEFAULT_PORT}`;

// SMTP (optional). If not set, links/ICS are printed in console.
const SMTP_HOST = process.env.SMTP_HOST || "";
const SMTP_PORT = Number(process.env.SMTP_PORT || 587);
const SMTP_USER = process.env.SMTP_USER || "";
const SMTP_PASS = process.env.SMTP_PASS || "";
const FROM_EMAIL = process.env.FROM_EMAIL || "hr@localhost";

/* ---------- FS SETUP ---------- */
fse.ensureDirSync(PUBLIC_DIR);
fse.ensureDirSync(UPLOAD_DIR);
if (!fse.existsSync(DB_PATH)) {
  fse.writeJSONSync(
    DB_PATH,
    { nextIds: { candidate: 1, answer: 1 }, candidates: [], answers: [] },
    { spaces: 2 }
  );
}
if (!fse.existsSync(QUESTIONS_PATH)) {
  fse.writeJSONSync(
    QUESTIONS_PATH,
    {
      questions: [
        "Tell me about yourself.",
        "Why do you want this job?",
        "Describe a challenge you overcame.",
      ],
    },
    { spaces: 2 }
  );
}
if (!fse.existsSync(INVITES_PATH)) {
  fse.writeJSONSync(INVITES_PATH, [], { spaces: 2 });
}

/* ---------- HELPERS ---------- */
const loadDB = () => fse.readJSONSync(DB_PATH);
const saveDB = (db) => fse.writeJSONSync(DB_PATH, db, { spaces: 2 });

const loadInvites = () => fse.readJSONSync(INVITES_PATH);
const saveInvites = (arr) => fse.writeJSONSync(INVITES_PATH, arr, { spaces: 2 });

function computeCandidateScore(db, cid) {
  const answers = db.answers.filter((a) => a.candidate_id === cid);
  if (!answers.length) return null;
  const avgSec =
    answers.reduce((s, a) => s + (Number(a.duration_ms || 0) / 1000), 0) /
    answers.length;
  return Math.max(0, Math.min(100, Math.round((avgSec / 60) * 100)));
}

function latestAnswerTime(db, cid) {
  const answers = db.answers.filter((a) => a.candidate_id === cid);
  if (!answers.length) return null;
  return answers.reduce((max, a) => {
    return max && new Date(max) > new Date(a.created_at) ? max : a.created_at;
  }, null);
}

function clamp01(n) {
  const x = Number(n);
  if (!Number.isFinite(x)) return null;
  return Math.max(0, Math.min(1, x));
}

// average helper (returns integer or null)
function avg(nums) {
  const arr = (nums || []).filter(
    (v) => typeof v === "number" && Number.isFinite(v)
  );
  if (!arr.length) return null;
  return Math.round(arr.reduce((s, v) => s + v, 0) / arr.length);
}

function aggregateCandidateMetrics(db, cid) {
  const answers = db.answers.filter((a) => a.candidate_id === cid && a.metrics);
  if (!answers.length) return null;
  const sum = {
    confidence: 0,
    communication: 0,
    engagement: 0,
    professionalism: 0,
  };
  const cnt = {
    confidence: 0,
    communication: 0,
    engagement: 0,
    professionalism: 0,
  };
  for (const a of answers) {
    const m = a.metrics || {};
    if (typeof m.confidence === "number") {
      sum.confidence += m.confidence;
      cnt.confidence++;
    }
    if (typeof m.communication === "number") {
      sum.communication += m.communication;
      cnt.communication++;
    }
    if (typeof m.engagement === "number") {
      sum.engagement += m.engagement;
      cnt.engagement++;
    }
    if (typeof m.professionalism === "number") {
      sum.professionalism += m.professionalism;
      cnt.professionalism++;
    }
  }
  const out = {};
  for (const k of Object.keys(sum)) {
    out[k] = cnt[k] ? Math.round((sum[k] / cnt[k]) * 100) : null; // 0..1 -> 0..100
  }
  return out;
}

function requireAdmin(req, res, next) {
  const key = req.headers["x-admin-key"] || req.query.key;
  if (key !== ADMIN_KEY) return res.status(401).json({ error: "Unauthorized" });
  next();
}

/* ---------- EMAIL/CALENDAR HELPERS ---------- */
function buildTransporter() {
  if (!SMTP_HOST || !SMTP_USER || !SMTP_PASS) return null;
  return nodemailer.createTransport({
    host: SMTP_HOST,
    port: SMTP_PORT,
    secure: SMTP_PORT === 465,
    auth: { user: SMTP_USER, pass: SMTP_PASS },
  });
}
function toLocal(iso, tz = TZ) {
  return new Date(iso).toLocaleString("en-AU", { timeZone: tz });
}
function generateSlots({ days = 7, tz = TZ, durationMins = 30 }) {
  const slots = [];
  const start = new Date();
  start.setHours(0, 0, 0, 0);
  for (let d = 0; d < days; d++) {
    const day = new Date(start.getTime() + d * 24 * 60 * 60 * 1000);
    const dow = day.getDay(); // 0 Sun ... 6 Sat
    if (dow === 0 || dow === 6) continue; // weekdays only
    [10, 14].forEach((hour) => {
      const s = new Date(day);
      s.setHours(hour, 0, 0, 0);
      const e = new Date(s.getTime() + durationMins * 60000);
      slots.push({ startISO: s.toISOString(), endISO: e.toISOString(), tz });
    });
  }
  return slots;
}
function makeICS({
  title,
  description,
  location,
  startISO,
  endISO,
  organizerEmail,
  attendeeEmail,
}) {
  const s = new Date(startISO);
  const e = new Date(endISO);
  const toArr = (dt) => [
    dt.getFullYear(),
    dt.getMonth() + 1,
    dt.getDate(),
    dt.getHours(),
    dt.getMinutes(),
  ];
  return new Promise((resolve, reject) => {
    createEvent(
      {
        start: toArr(s),
        end: toArr(e),
        title,
        description,
        location,
        organizer: { name: "HR Team", email: organizerEmail },
        attendees: [{ name: "Candidate", email: attendeeEmail, rsvp: true }],
        status: "CONFIRMED",
        productId: "hr-video-app",
        busyStatus: "BUSY",
      },
      (err, value) => {
        if (err) return reject(err);
        resolve(value);
      }
    );
  });
}

/* ---------- APP MIDDLEWARE ---------- */
app.use("/", express.static(PUBLIC_DIR));
app.use("/uploads", express.static(UPLOAD_DIR));
app.use(express.json());
// urlencoded parser MUST be before the confirm POST
app.use(express.urlencoded({ extended: true }));

const upload = multer({
  dest: UPLOAD_DIR,
  limits: { fileSize: 200 * 1024 * 1024 }, // 200MB
});

/* ---------- ROUTES: CORE WORKFLOW ---------- */

// Health
app.get("/api/health", (req, res) =>
  res.json({ ok: true, time: new Date().toISOString() })
);

// Candidate registration
app.post("/api/submitCandidate", (req, res) => {
  const { name, email, phone, role, experience } = req.body || {};
  if (!name || !email)
    return res.status(400).json({ error: "name+email required" });

  const db = loadDB();
  const id = db.nextIds.candidate++;
  db.candidates.push({
    id,
    name,
    email,
    phone: phone || "",
    role: role || "",
    experience: experience || "",
    created_at: new Date().toISOString(),
    shortlisted: false,
    stage: "Registered",
    score: null,
    notes: "",
    tags: [],
    resume_path: null,
    invite_link: null,
  });
  saveDB(db);
  res.json({ ok: true, candidateId: id });
});

// Resume upload
app.post("/api/candidates/:id/resume", upload.single("resume"), (req, res) => {
  const id = Number(req.params.id);
  const db = loadDB();
  const c = db.candidates.find((x) => x.id === id);
  if (!c) return res.status(404).json({ error: "Not found" });
  if (!req.file) return res.status(400).json({ error: "Missing resume file" });
  c.resume_path = "uploads/" + req.file.filename;
  saveDB(db);
  res.json({ ok: true, resume_path: c.resume_path });
});

// Questions
app.get("/api/questions", (req, res) => {
  try {
    const q = fse.readJSONSync(QUESTIONS_PATH);
    if (!q || !Array.isArray(q.questions))
      throw new Error("Invalid questions file");
    res.json({ questions: q.questions });
  } catch (e) {
    res.status(500).json({ error: "Failed to load questions file" });
  }
});

// Upload one answer per question (accepts optional soft-skill metrics)
app.post("/api/uploadAnswer/:cid/:qnum", upload.single("file"), (req, res) => {
  const cid = Number(req.params.cid);
  const qnum = Number(req.params.qnum);
  const db = loadDB();

  if (!db.candidates.find((c) => c.id === cid))
    return res.status(404).json({ error: "Candidate not found" });
  if (!req.file) return res.status(400).json({ error: "Missing video file" });

  const durationMs =
    req.body && req.body.durationMs ? parseInt(req.body.durationMs, 10) : null;

  let metrics = null;
  try {
    if (req.body.metrics) {
      const raw =
        typeof req.body.metrics === "string"
          ? JSON.parse(req.body.metrics)
          : req.body.metrics;
      metrics = {
        confidence: clamp01(raw.confidence),
        communication: clamp01(raw.communication ?? raw.communication_clarity),
        engagement: clamp01(raw.engagement),
        professionalism: clamp01(raw.professionalism),
      };
      if (
        ![
          metrics.confidence,
          metrics.communication,
          metrics.engagement,
          metrics.professionalism,
        ].some((v) => v !== null)
      ) {
        metrics = null;
      }
    } else if (
      req.body.confidence ||
      req.body.communication ||
      req.body.engagement ||
      req.body.professionalism
    ) {
      metrics = {
        confidence: clamp01(req.body.confidence),
        communication: clamp01(req.body.communication),
        engagement: clamp01(req.body.engagement),
        professionalism: clamp01(req.body.professionalism),
      };
      if (
        ![
          metrics.confidence,
          metrics.communication,
          metrics.engagement,
          metrics.professionalism,
        ].some((v) => v !== null)
      ) {
        metrics = null;
      }
    }
  } catch {
    metrics = null;
  }

  const id = db.nextIds.answer++;
  db.answers.push({
    id,
    candidate_id: cid,
    question_id: qnum,
    video_path: "uploads/" + req.file.filename,
    duration_ms: Number.isFinite(durationMs) ? durationMs : null,
    metrics,
    created_at: new Date().toISOString(),
  });

  const cand = db.candidates.find((c) => c.id === cid);
  if (cand && cand.stage === "Registered") cand.stage = "Interviewed";
  cand.score = computeCandidateScore(db, cid);

  saveDB(db);
  res.json({ ok: true, score: cand.score });
});

/* ---------- ADMIN LIST (returns the 4 metrics + average score) ---------- */
app.get("/api/admin/candidates", requireAdmin, (req, res) => {
  const { search = "", stage = "", shortlisted = "" } = req.query || {};
  const db = loadDB();

  let list = db.candidates.map((c) => {
    const answersCount = db.answers.filter((a) => a.candidate_id === c.id).length;
    const updated = latestAnswerTime(db, c.id) || c.created_at;
    const soft = aggregateCandidateMetrics(db, c.id); // {confidence, communication, engagement, professionalism} 0..100 or null

    const confidence = soft ? soft.confidence : null;
    const communication = soft ? soft.communication : null;
    const engagement = soft ? soft.engagement : null;
    const professionalism = soft ? soft.professionalism : null;
    const score = avg([confidence, communication, engagement, professionalism]); // 0..100 or null

    return {
      ...c,
      answers: answersCount,
      updated_at: updated,
      metrics_avg: soft || null, // kept for backwards compatibility
      confidence,
      communication,
      engagement,
      professionalism,
      score,
    };
  });

  const q = search.trim().toLowerCase();
  if (q) {
    list = list.filter((c) =>
      [c.name, c.email, c.role, c.phone, (c.tags || []).join(",")].some((v) =>
        (v || "").toLowerCase().includes(q)
      )
    );
  }
  if (stage) list = list.filter((c) => (c.stage || "") === stage);
  if (String(shortlisted || "").toLowerCase() === "true") {
    list = list.filter((c) => c.shortlisted);
  }

  list.sort((a, b) => new Date(b.updated_at) - new Date(a.updated_at));
  res.json(list);
});

/* ---------- ADMIN DETAILS (0–100 metrics per answer) ---------- */
app.get("/api/admin/candidates/:id", requireAdmin, (req, res) => {
  const id = Number(req.params.id);
  const db = loadDB();
  const candidate = db.candidates.find((c) => c.id === id);
  if (!candidate) return res.status(404).json({ error: "Not found" });
  const answers = db.answers
    .filter((a) => a.candidate_id === id)
    .sort((a, b) => a.question_id - b.question_id)
    .map((a) => {
      const m = a.metrics || {};
      const norm = (x) =>
        typeof x === "number" ? Math.round(Math.max(0, Math.min(1, x)) * 100) : null;
      return {
        ...a,
        metrics_100: {
          confidence: norm(m.confidence),
          communication: norm(m.communication),
          engagement: norm(m.engagement),
          professionalism: norm(m.professionalism),
        },
      };
    });
  res.json({ candidate, answers });
});

// Update candidate (notes/tags/shortlisted only)
app.patch("/api/admin/candidates/:id", requireAdmin, (req, res) => {
  const id = Number(req.params.id);
  const { notes, tags, shortlisted } = req.body || {};
  const db = loadDB();
  const c = db.candidates.find((x) => x.id === id);
  if (!c) return res.status(404).json({ error: "Not found" });

  if (typeof notes !== "undefined") c.notes = notes;
  if (Array.isArray(tags)) c.tags = tags;
  if (typeof shortlisted === "boolean") c.shortlisted = shortlisted;

  saveDB(db);
  res.json({ ok: true, candidate: c });
});

// Toggle shortlist (button)
app.post("/api/admin/candidates/:id/shortlist", requireAdmin, (req, res) => {
  const id = Number(req.params.id);
  const db = loadDB();
  const c = db.candidates.find((x) => x.id === id);
  if (!c) return res.status(404).json({ error: "Not found" });
  c.shortlisted = !c.shortlisted;
  saveDB(db);
  res.json({ ok: true, shortlisted: c.shortlisted });
});

// Old: Invite link (Meet/Zoom) — unchanged
app.post("/api/admin/candidates/:id/invite", requireAdmin, (req, res) => {
  const id = Number(req.params.id);
  const { meeting_url } = req.body || {};
  if (!meeting_url) return res.status(400).json({ error: "meeting_url required" });

  const db = loadDB();
  const candidate = db.candidates.find((c) => c.id === id);
  if (!candidate) return res.status(404).json({ error: "Candidate not found" });

  const token = crypto.randomBytes(6).toString("hex");
  const invite_link =
    meeting_url +
    (meeting_url.includes("?") ? "&" : "?") +
    "t=" +
    token +
    "&cid=" +
    id;
  candidate.invite_link = invite_link;
  saveDB(db);
  res.json({ ok: true, invite_link });
});

// CSV export
app.get("/api/admin/export", requireAdmin, (req, res) => {
  const db = loadDB();
  const header = [
    "id",
    "name",
    "email",
    "phone",
    "role",
    "experience",
    "stage",
    "shortlisted",
    "score",
    "tags",
    "created_at",
    "invite_link",
    "resume_path",
    "answers",
  ];
  const rows = db.candidates.map((c) => {
    const answers = db.answers.filter((a) => a.candidate_id === c.id).length;
    return [
      c.id,
      c.name,
      c.email,
      c.phone || "",
      c.role || "",
      c.experience || "",
      c.stage || "",
      c.shortlisted ? "YES" : "NO",
      c.score ?? "",
      (c.tags || []).join("|"),
      c.created_at,
      c.invite_link || "",
      c.resume_path || "",
      answers,
    ];
  });
  const csv = [
    header.join(","),
    ...rows.map((r) =>
      r.map((v) => `"${String(v).replace(/"/g, '""')}"`).join(",")
    ),
  ].join("\n");
  res.setHeader("Content-Type", "text/csv");
  res.setHeader(
    "Content-Disposition",
    'attachment; filename="candidates.csv"'
  );
  res.send(csv);
});

/* ---------- CALENDAR SLOTS ---------- */

// Preview slots
app.get("/api/admin/invite/slots", requireAdmin, (req, res) => {
  const days = Math.min(Number(req.query.days || 7), 21);
  const duration = Math.min(Number(req.query.duration || 30), 120);
  res.json(generateSlots({ days, durationMins: duration }));
});

// Send slot links to candidate (dashboard calls this)
app.post(
  "/api/admin/candidates/:id/invite-slots",
  requireAdmin,
  async (req, res) => {
    try {
      const id = String(req.params.id);
      const { interviewerEmail, duration = 30, customSlots } = req.body || {};

      if (
        !interviewerEmail ||
        !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(interviewerEmail)
      ) {
        return res.status(400).json({ error: "Valid interviewerEmail is required" });
      }

      const db = loadDB();
      const cand = (db.candidates || []).find((c) => String(c.id) === id);
      if (!cand) return res.status(404).json({ error: "Candidate not found" });
      if (!cand.email) return res.status(400).json({ error: "Candidate email missing" });

      const dur = Math.max(15, Math.min(120, Number(duration) || 30));
      const slots =
        Array.isArray(customSlots) && customSlots.length
          ? customSlots
          : generateSlots({ days: 7, durationMins: dur });

      const invites = loadInvites();
      const items = slots.slice(0, 6).map((s) => ({
        token: uuidv4(),
        candidateId: cand.id,
        interviewerEmail,
        candidateEmail: cand.email,
        startISO: s.startISO,
        endISO: s.endISO,
        tz: s.tz || TZ,
        status: "pending",
        createdAt: Date.now(),
      }));
      invites.push(...items);
      saveInvites(invites);

      const linksHtml = items
        .map(
          (it) =>
            `<li><a href="${BASE_URL}/book/${it.token}">${toLocal(
              it.startISO
            )} – ${toLocal(it.endISO)} (${it.tz})</a></li>`
        )
        .join("");

      const html = `
        <p>Hi ${cand.name || "there"},</p>
        <p>We’d like to invite you to a face-to-face interview. Please pick one of the times below:</p>
        <ul>${linksHtml}</ul>
        <p>If none work, reply to this email with your availability.</p>
        <p>Regards,<br/>HR Team</p>
      `;

      const transporter = buildTransporter();
      if (transporter) {
        transporter
          .sendMail({
            from: FROM_EMAIL,
            to: cand.email,
            subject: "Interview Invitation – Select a time",
            html,
          })
          .catch((e) => {
            console.warn("[WARN] Email send failed:", e?.message);
            const plain = items
              .map(
                (it) =>
                  `- ${toLocal(it.startISO)} – ${toLocal(it.endISO)} (${it.tz}): ${BASE_URL}/book/${it.token}`
              )
              .join("\n");
            console.log("[INFO] Links you can copy/paste:\n" + plain);
          });
      } else {
        // SMTP not set → just print the raw links with times (safe to copy/paste)
        const plain = items
          .map(
            (it) =>
              `- ${toLocal(it.startISO)} – ${toLocal(it.endISO)} (${it.tz}): ${BASE_URL}/book/${it.token}`
          )
          .join("\n");
        console.log("[INFO] SMTP not configured – send these links manually:\n" + plain);
      }

      return res.json({ ok: true, sentTo: cand.email, slots: items.length });
    } catch (err) {
      console.error("invite-slots route error:", err);
      return res.status(500).json({ error: "Internal error in invite-slots" });
    }
  }
);

// Candidate booking page (includes POST and an explicit GET link to confirm)
app.get("/book/:token", (req, res) => {
  const invites = loadInvites();
  const it = invites.find((x) => x.token === req.params.token);
  if (!it) return res.status(404).send("<h1>Invalid or expired link</h1>");
  if (it.status === "confirmed") {
    return res.send(
      "<h1>Already confirmed ✅</h1><p>Your interview has been scheduled. Check your email for the calendar invite.</p>"
    );
  }
  res.send(`
    <h1>Confirm your interview</h1>
    <p><b>Time:</b> ${toLocal(it.startISO)} – ${toLocal(it.endISO)} (${it.tz})</p>
    <form method="POST" action="/api/invite/confirm" style="margin-bottom:12px">
      <input type="hidden" name="token" value="${it.token}" />
      <button type="submit">Confirm</button>
    </form>
    <div>Or click this link: <a href="/api/invite/confirm?token=${it.token}">Confirm interview</a></div>
  `);
});

// Unified confirm handler (accepts POST body or GET query)
async function handleConfirm(req, res) {
  try {
    const token =
      (req.body && req.body.token) || (req.query && req.query.token) || "";
    if (!token) return res.status(400).send("<h1>Missing token</h1>");

    const invites = loadInvites();
    const idx = invites.findIndex((x) => x.token === token);
    if (idx === -1) return res.status(404).send("<h1>Invalid or expired link</h1>");

    const it = invites[idx];
    if (it.status === "confirmed") {
      return res.send("<h1>Already confirmed ✅</h1><p>Invite already sent.</p>");
    }

    // Build and (optionally) send ICS
    try {
      const ics = await makeICS({
        title: "Face-to-Face Interview",
        description: "HR interview scheduled via hr-video-app",
        location: "Office (details in email) or as arranged",
        startISO: it.startISO,
        endISO: it.endISO,
        organizerEmail: it.interviewerEmail,
        attendeeEmail: it.candidateEmail,
      });

      const transporter = buildTransporter();
      if (transporter) {
        await transporter.sendMail({
          from: FROM_EMAIL,
          to: it.candidateEmail,
          cc: it.interviewerEmail,
          subject: "Interview Confirmed",
          text: `Your interview is confirmed: ${toLocal(it.startISO)} – ${toLocal(it.endISO)} (${it.tz})`,
          icalEvent: { filename: "invite.ics", method: "REQUEST", content: ics },
        });
      } else {
        console.log(
          "[INFO] SMTP not configured – ICS not emailed. Save this as invite.ics if needed:\n"
        );
        console.log(ics);
      }
    } catch (mailErr) {
      console.error("[CONFIRM] ICS/email step failed:", mailErr);
      // still continue — we want to mark confirmed even if email fails
    }

    // Mark confirmed and write into candidate record
    invites[idx].status = "confirmed";
    invites[idx].confirmedAt = Date.now();
    saveInvites(invites);

    const db = loadDB();
    const c = db.candidates.find((x) => x.id === it.candidateId);
    if (c) {
      c.stage = "F2F Scheduled";
      c.booked_start = it.startISO;
      c.booked_end = it.endISO;
      c.booked_tz = it.tz || TZ;
      saveDB(db);
    }

    return res.send(
      "<h1>Confirmed ✅</h1><p>We’ve recorded your interview time. A calendar invite will be emailed if email is configured.</p>"
    );
  } catch (err) {
    console.error("[CONFIRM] Unexpected error:", err);
    return res.status(500).send("<h1>Failed to confirm. Please try again later.</h1>");
  }
}

// Accept POST and GET for the same path
app.post("/api/invite/confirm", handleConfirm);
app.get("/api/invite/confirm", handleConfirm);

/* ---------- START ---------- */
app.listen(DEFAULT_PORT, () => {
  console.log(`HR app → ${BASE_URL}`);
});
